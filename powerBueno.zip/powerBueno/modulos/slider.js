import { slidesData } from './data.js';


class Slider {
    constructor() {
        this.slides = slidesData.slides;
        this.currentSlide = 0;

        this.renderSlides();
        this.showSlide(this.currentSlide);

        document.getElementById('next').addEventListener('click', () => this.nextSlide());
        document.getElementById('prev').addEventListener('click', () => this.prevSlide());
    }

    renderSlides() {
        const slideContainer = document.getElementById('slides');
        slideContainer.innerHTML = ''; 

        const currentSlideData = this.slides[this.currentSlide];

        const slideDiv = document.createElement('div');
        slideDiv.classList.add('slide');

        const titulo = document.createElement('h2');
        titulo.textContent = currentSlideData.title;

        const subtitulo = document.createElement('h3');
        subtitulo.textContent = currentSlideData.subtitle;

        const parrafillo = document.createElement('p');
        parrafillo.innerHTML = currentSlideData.content;

        slideDiv.appendChild(titulo);
        slideDiv.appendChild(subtitulo);
        slideDiv.appendChild(parrafillo);

        slideContainer.appendChild(slideDiv);
    }

    showSlide(index) {
        const allSlides = document.querySelectorAll('.slide');
        allSlides.forEach(slide => slide.style.display = 'none'); 
        allSlides[index].style.display = 'block'; 
    }

    nextSlide() {
        this.currentSlide = (this.currentSlide + 1) % this.slides.length;
        console.log(this.currentSlide);
        this.renderSlides();
    }

    prevSlide() {
        this.currentSlide = (this.currentSlide - 1 + this.slides.length) % this.slides.length;
        console.log(this.currentSlide);
        this.renderSlides();
    }
}

export  {Slider};
