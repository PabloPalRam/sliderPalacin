const slidesData = {
    slides: [
        {
            title: "Slide 1",
            subtitle: "Hola soy el primero",
            content: "<p>Contenido de la primera diapositiva.</p>"
        },
        {
            title: "Slide 2",
            subtitle: "Hola soy el segundo",
            content: "<p>Contenido de la segunda diapositiva.</p>"
        },
        {
            title: "Slide 3",
            subtitle: "Hola soy el tercero",
            content: "<p>Contenido de la tercera diapositiva.</p>"
        },
        {
            title: "Slide 4",
            subtitle: "Hola soy el cuarto",
            content: "<p>Contenido de la cuarta diapositiva.</p>"
        },
        {
            title: "Slide 5",
            subtitle: "Hola soy el quinto",
            content: "<p>Contenido de la quinta diapositiva.</p>"
        },
        {
            title: "Slide 6",
            subtitle: "Hola soy el sexto",
            content: "<p>Contenido de la sexta diapositiva.</p>"
        }
    ]
};

export { slidesData };
