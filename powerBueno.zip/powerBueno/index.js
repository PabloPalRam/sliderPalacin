// index.js
import {Slider} from './modulos/slider.js';

let slider = new Slider();

